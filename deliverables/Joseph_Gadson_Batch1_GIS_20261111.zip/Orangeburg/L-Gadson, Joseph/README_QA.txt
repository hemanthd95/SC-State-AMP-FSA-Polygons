SCSU AMP: Joseph Gadson, Orangeburg County
Shapefile: JosephGadson.shp/ (EPSG:4326; one record per accepted field)
County context map: JosephGadson-CountyMap.pdf (topographic)
Farmer field map: JosephGadson-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Bonner Ave', 'State Rd S-38-172', 'Brookstone Rd', 'Lantana Ct', 'Barcelona Dr']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
