SCSU AMP / Joseph Gadson
Source Farm 4547, Tract 4482. Fields included: 3, 4
STATUS: SOURCE_PARTIAL_ENROLLMENT_IDS_MISSING
ENROLLMENT STATUS: Year2 enrollment Farm/Tract/Field missing; source fields 12,3,10,9,4 visible
Only the source-labeled, georeferenced, acreage-checked field geometries were included.
Do not mistake this subset for a completed enrolled farmer when selection is missing.
WGS84 (EPSG:4326) farmer shapefile, topographic context and road-labeled satellite PDFs.
FSA administrative/printing county was ignored when determining physical location.
Geometries are approximate photo-source field outlines, NOT legal/cadastral surveys.
