SCSU AMP: Arthur Cobbs, Dorchester County
Shapefile: ArthurCobbs.shp/ (EPSG:4326; one record per accepted field)
County context map: ArthurCobbs-CountyMap.pdf (topographic)
Farmer field map: ArthurCobbs-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Wimberly Dairy Farm Rd', 'Mack Ln', 'Prosperity Ln', 'Sugar Shack Ln', 'Cliffton Dr']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
