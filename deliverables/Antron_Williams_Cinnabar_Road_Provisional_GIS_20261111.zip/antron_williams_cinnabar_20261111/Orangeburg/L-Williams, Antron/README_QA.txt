SCSU AMP: Antron Williams, Orangeburg County
Shapefile: AntronWilliams.shp/ (EPSG:4326; one record per accepted field)
County context map: AntronWilliams-CountyMap.pdf (topographic)
Farmer field map: AntronWilliams-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 3. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['O C 4118', 'Cinnabar Rd', 'Winningham Dr', 'Gordon Dr', 'State Rd S-38-1443']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
