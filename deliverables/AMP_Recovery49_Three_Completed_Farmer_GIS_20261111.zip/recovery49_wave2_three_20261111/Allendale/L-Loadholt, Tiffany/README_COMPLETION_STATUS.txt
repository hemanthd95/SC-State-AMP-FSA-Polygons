Tiffany Loadholt - Year2 registered enrolled field: Farm 3779 Tract 10394 Field 54
USGS NAIP inliers 85, residual 0.772 pixels.
FSA 15.18 acres vs 14.100 mapped acres (-7.1%).
Physical county: Allendale. FSA office county is NOT a location criterion.
EPSG:4326 farmer shapefile + county topo and road-labeled satellite PDFs included.
Approximate field geometry for research planning, not a legal survey or claim of ownership.
