SCSU AMP: Eartha Pinckney, Colleton County
Shapefile: EarthaPinckney.shp/ (EPSG:4326; one record per accepted field)
County context map: EarthaPinckney-CountyMap.pdf (topographic)
Farmer field map: EarthaPinckney-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['McDanieltown Rd', 'State Rd S-15-91', 'Florence Ln', 'Hartline Ln', 'Honor Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
