Eartha Pinckney - Year2 registered enrolled field: Farm 6579 Tract 22687 Field 11
USGS NAIP inliers 138, residual 0.714 pixels.
FSA 5.81 acres vs 5.973 mapped acres (+2.8%).
Physical county: Colleton. FSA office county is NOT a location criterion.
EPSG:4326 farmer shapefile + county topo and road-labeled satellite PDFs included.
Approximate field geometry for research planning, not a legal survey or claim of ownership.
