Jan Davis Boneparte - Year2 registered enrolled field: Farm 3549 Tract 8353 Field 2
USGS NAIP inliers 201, residual 0.580 pixels.
FSA 7.72 acres vs 7.556 mapped acres (-2.1%).
Physical county: Orangeburg. FSA office county is NOT a location criterion.
EPSG:4326 farmer shapefile + county topo and road-labeled satellite PDFs included.
Approximate field geometry for research planning, not a legal survey or claim of ownership.
