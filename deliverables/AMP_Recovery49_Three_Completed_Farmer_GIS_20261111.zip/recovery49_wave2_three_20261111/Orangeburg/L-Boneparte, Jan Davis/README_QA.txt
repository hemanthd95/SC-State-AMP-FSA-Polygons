SCSU AMP: Jan Davis Boneparte, Orangeburg County
Shapefile: JanDavisBoneparte.shp/ (EPSG:4326; one record per accepted field)
County context map: JanDavisBoneparte-CountyMap.pdf (topographic)
Farmer field map: JanDavisBoneparte-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Co Rd O C - 1307', 'Bonepart Rd', 'Generation Ln', 'Generation Dr', 'Dorothy Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
