SC STATE AMP: Three completed Year2 single-field farmers.
Tiffany Loadholt (3779/10394/54), Jan Davis Boneparte (3549/8353/2), Eartha Pinckney (6579/22687/11).
Completed here means the Year2 selected field identity+georegistration+acreage+map QA pass.
All polygons are FSA-photo-derived approximations and are not legal surveys.
