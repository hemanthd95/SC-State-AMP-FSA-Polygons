SCSU AMP: Charles Bright Jr., Colleton County
Shapefile: CharlesBrightJr.shp/ (EPSG:4326; one record per accepted field)
County context map: CharlesBrightJr-CountyMap.pdf (topographic)
Farmer field map: CharlesBrightJr-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 3. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [4, 5]
Road-label compliance: PASS
Roads: ['State Rd S-15-167', 'Pon Pon Plantation Ave', 'Pine Hill Ln', 'Cornflower Ln', 'Jo Rose Ln', 'Clinic Dr', 'Monarch Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
