Brenda M. Harris enrolled Field3 completed; QA and approximate boundary caveats inside farmer folder.
