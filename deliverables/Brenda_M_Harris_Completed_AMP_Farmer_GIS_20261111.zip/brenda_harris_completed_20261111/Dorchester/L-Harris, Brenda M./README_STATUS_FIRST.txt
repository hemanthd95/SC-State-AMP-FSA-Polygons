YEAR2 COMPLETION: Brenda M. Harris, FSA Farm4943, Tract4414, Field3.
Source 19.39 acres; geodesic trace 19.424 acres (difference +0.18%).
NAIP feature registration 142 inliers, 0.517px residual.
Physical county: Dorchester; source FSA printed county NOT used as locator.
One EPSG:4326 farmer shapefile, one county-topo PDF and one satellite PDF with 2+ named roads.
Not a cadastral survey; ground verification before legal/boundary decisions.
