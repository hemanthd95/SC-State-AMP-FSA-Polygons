SCSU AMP: Brenda M. Harris, Dorchester County
Shapefile: BrendaMHarris.shp/ (EPSG:4326; one record per accepted field)
County context map: BrendaMHarris-CountyMap.pdf (topographic)
Farmer field map: BrendaMHarris-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [2]
Road-label compliance: PASS
Roads: ['Old Spell Rd', 'Spotted Horse Trl']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
