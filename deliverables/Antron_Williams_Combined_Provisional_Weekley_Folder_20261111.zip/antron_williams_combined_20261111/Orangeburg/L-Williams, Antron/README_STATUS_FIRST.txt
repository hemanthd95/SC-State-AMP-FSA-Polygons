ANTRON WILLIAMS - FARM 11990 TRACT 44081
STATUS: PROVISIONALLY GEOREFERENCED SOURCE FIELDS; NOT YET COMPLETE AGAINST ENROLLMENT.
Data layers: Cinnabar FSA page5 Fields7,18,20; Gordon FSA page7 Fields61,3,16.
Field19 was REJECTED (computed acreage differs from FSA by 96%).
The Year2 master says enrolled Fields6 and7; source Field61 NOT proven to mean Field6.
Two registration methods: Cinnabar = 13 TIGER road controls, 3.38m road-curve RMSE,
  but no successful independent NAIP image-feature match.
Gordon = three manual road-control points against georeferenced NAIP, provisional.
These are approximate FSA research field polygons, NOT surveys or ownership evidence.
Each field's source registration limitations are retained in GeoJSON properties.
One EPSG:4326 producer shapefile in AntronWilliams.shp folder.
CountyMap.pdf one topo overview; FieldMap.pdf two satellite close-up pages.
Tax/producer-identification pages are excluded from this package.
