Margaret Berry GIS update. Read Orangeburg/L-Berry, Margaret/README_STATUS_FIRST.txt for acreage and completion caveats.
