Jasper Summers: three mapped FSA features; Year2 farmer NOT closed due to missing field selection/extra source tract.
