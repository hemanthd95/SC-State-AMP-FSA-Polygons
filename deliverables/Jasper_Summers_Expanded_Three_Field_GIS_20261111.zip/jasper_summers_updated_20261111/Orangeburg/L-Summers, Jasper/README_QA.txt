SCSU AMP: Jasper Summers, Orangeburg County
Shapefile: JasperSummers.shp/ (EPSG:4326; one record per accepted field)
County context map: JasperSummers-CountyMap.pdf (topographic)
Farmer field map: JasperSummers-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 3. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [5, 5]
Road-label compliance: PASS
Roads: ['O C 4148', 'Hollyhock Rd', 'Jerry Summers Dr', 'Middle Rd', 'O C 4147', 'O C 4338', 'Downing Dr', 'Greywood Dr', 'State Rd S-38-1691', 'O C 4151']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
