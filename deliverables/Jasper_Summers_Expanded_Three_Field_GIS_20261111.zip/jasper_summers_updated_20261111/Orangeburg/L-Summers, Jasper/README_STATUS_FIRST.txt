JASPER SUMMERS — Year2 FARM13709 MAPPING EXPANDED, STILL OPEN FOR FIELD RECONCILIATION.
Registered Year2 Farm13709 Tract45514 Fields8 (4.70 ac source) and17 (2.92 ac source).
Combined FSA source 7.62 ac vs program enrollment 8.0 ac, exact field ID blank on Year2 roster.
Also retained existing Farm13653 Tract5515 Field1 validated older source (2.58ac).
Unregistered from Farm13709 Tract45512 source page3: Field16 (2.34ac), Field27 (0.20ac).
Image registration: USGS NAIP 97 inliers, 0.374px RMSE (page1 only).
The FSA printed office county is not used as a geospatial position constraint.
All boundaries are approximate FSA photo traces, not surveys.
