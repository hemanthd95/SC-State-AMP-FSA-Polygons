SCSU AMP: Lewis Gin, Hampton County
Shapefile: LewisGin.shp/ (EPSG:4326; one record per accepted field)
County context map: LewisGin-CountyMap.pdf (topographic)
Farmer field map: LewisGin-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [2]
Road-label compliance: PASS
Roads: ['Pocotaligo Rd', 'Co Rd S-25-68']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
