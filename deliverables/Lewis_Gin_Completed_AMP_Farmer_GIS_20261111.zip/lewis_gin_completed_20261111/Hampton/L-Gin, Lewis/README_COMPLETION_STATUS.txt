LEWIS GIN - Year2 Farm4706 Tract11322 Field36 COMPLETED FOR RESEARCH MAPPING
FSA 5.94 acres; digitized geodetic 5.942 acres; error +0.04%.
USGS NAIP registration: 119 SIFT inliers; 0.693 pixel residual.
Physical county from independent Census mapping, not USDA FSA office header.
Annette Weekley shares farm+tract but this is Lewis's separate enrolled Field36.
Field13 appears on original annotated FSA source but is not the Year2 selected Field36.
One WGS84 farmer shapefile, county topo PDF, satellite field PDF with 2 named streets.
Approximate FSA map shape only, not surveyed property ownership or legal boundary.
