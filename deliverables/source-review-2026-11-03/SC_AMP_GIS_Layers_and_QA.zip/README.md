# SC AMP/FSA source-review and GIS package

**PRIVATE — PARTIAL DELIVERY. These are source-review PDFs, not completed satellite/topographic atlases.**

Start with `qa/verification_report.md` and `qa/completion_status.json`.

- `source_review_pdfs/`: 17 x 11-inch county reference documents with source FSA map insets and complete inventory/exception accounting.
- `geojson/SC_AMP_FSA_All_Farm_Fields.geojson`: 22 corrected, source-reproduced field polygons. Some fields may not be enrolled program fields.
- `geojson/SC_AMP_FSA_All_Farms.geojson`: 120 listed county/Farm-ID combinations; 114 have null boundaries.
- `geojson/Registered_Source_Farms.geojson`: six valid source-map farm geometries; source-supported county corrections are documented in QA.
- `geojson/SC_AMP_FSA_Farm_Locations.geojson`: registered representative points or usable approximate reported coordinates; other geometries are null.
- `geojson/Unresolved_Enrollment_Records.geojson`: four missing-Farm-ID enrollment rows with null geometry; Saluda county layers are empty pending resolution.
- `geojson/counties/`, `shapefiles/counties/`: county Fields, Farms and Locations layers. Empty/null geometries are intentional and must not be filled with invented boundaries.
- `qa/`: provenance, enrollment crosswalk, coordinate exceptions, extraction status, acreage/reference QA and page validation.
- `previews/`: raster rendering of every review PDF page plus contact sheets.

All GeoJSON/Shapefile coordinates use EPSG:4326 longitude, latitude. EPSG:32617 is used for distance/area/reference comparisons. Shapefile attributes use county, farm_id, tract_id, field_id, fsa_acres and status; full provenance is retained in GeoJSON and QA.

County boundaries: U.S. Census Bureau CitySDK, 2022 cartographic boundaries, 1:500,000; https://github.com/uscensusbureau/citysdk/blob/fc5d7880529fedcde181269fc5d518767221281e/v2/GeoJSON/500k/2022/county.json . Only data were used from that archived repository. Source imagery: supplied USDA FSA maps; no crop or property-ownership inference.

Original source documents and contact/tax forms are not included in the delivery ZIP. Keep derived farm-level maps and identifiers private.

Reproduction in the prepared cloud environment: `bash scripts/run_atlas_review.sh` from the source repository. Dependencies are pinned in `scripts/atlas-requirements.txt`; system GDAL and Tesseract are also required. The script inventories documents, OCRs pages, reconciles records, reproduces GeoPDF polygons, exports layers and builds review PDFs. It does not implement completed scanned-map control-point georeferencing or final satellite/topographic atlas production.
