Producer: Calvin Blair
Status: SOURCE_FARM_MATCHES_BUT_IMAGE_LOCATION_UNRESOLVED
Farm3603/Tract848 source page includes Field3 (12.50 acres). Existing local SIFT match was geometrically degenerate.
No accepted EPSG:4326 source-field polygon. Do not count this folder as completed.
No shapefile or field-location PDF has been fabricated.
