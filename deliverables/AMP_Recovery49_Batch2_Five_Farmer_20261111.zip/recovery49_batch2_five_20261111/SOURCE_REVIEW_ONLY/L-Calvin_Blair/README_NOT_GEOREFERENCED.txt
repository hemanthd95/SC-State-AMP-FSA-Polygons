Calvin Blair Farm3603/Tract848/Field3 (12.50 FSA acres): not yet located geographically.
A widened search loaded 369 USGS NAIP and Esri aerial tiles within roughly 11km of the Excel address.
Best SIFT feature match was degenerate (target spatial spread zero), so no geographic polygon was accepted.
Calvin Blair and Tyrease Riley supplied pixel-identical FSA map pages for Farm3603/Tract848.
Source Field1 (16.96ac) belongs to Tyrease, source Field3 (12.50ac) belongs to Calvin;
reusing the eventual independent farm image registration can efficiently map both.
The source FSA county is not a physical field locator. Do not invent coordinates.
