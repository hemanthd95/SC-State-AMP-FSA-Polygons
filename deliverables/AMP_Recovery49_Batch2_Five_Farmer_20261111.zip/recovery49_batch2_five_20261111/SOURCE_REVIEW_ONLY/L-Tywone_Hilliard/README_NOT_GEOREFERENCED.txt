Producer: Tywone Hilliard
Status: THREE_IMAGE_REGISTRATIONS_SOURCE_IDS_UNRECONCILED
Three 2024 photographed field-map pages registered geographically; enrolled Farms1064 and3826 not confirmed from these maps.
No accepted EPSG:4326 source-field polygon. Do not count this folder as completed.
No shapefile or field-location PDF has been fabricated.
