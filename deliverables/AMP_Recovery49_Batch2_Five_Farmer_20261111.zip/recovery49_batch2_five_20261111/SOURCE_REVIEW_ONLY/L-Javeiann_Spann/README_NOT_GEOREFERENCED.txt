Producer: Javeiann Spann
Status: SOURCE_DIGITIZED_LOCATION_UNRESOLVED
Year2 3988/4673/1; user supplied two photographs including unrelated 9447/8142; no unique independent NAIP match.
No accepted EPSG:4326 source-field polygon. Do not count this folder as completed.
No shapefile or field-location PDF has been fabricated.
