Producer: Joe Hilliard
Status: IMAGE_REGISTERED_SOURCE_FARM_MISMATCH
612 NAIP features registered source Farm6528/Tract41114; Year2 target Farm13859/Tract45814/Field20; do NOT substitute source field.
No accepted EPSG:4326 source-field polygon. Do not count this folder as completed.
No shapefile or field-location PDF has been fabricated.
