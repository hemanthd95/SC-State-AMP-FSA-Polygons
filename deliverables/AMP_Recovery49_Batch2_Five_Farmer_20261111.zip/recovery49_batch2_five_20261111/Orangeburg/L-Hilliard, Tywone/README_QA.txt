SCSU AMP: Tywone Hilliard, Orangeburg County
Shapefile: TywoneHilliard.shp/ (EPSG:4326; one record per accepted field)
County context map: TywoneHilliard-CountyMap.pdf (topographic)
Farmer field map: TywoneHilliard-FieldMap.pdf (3 separate satellite field-close-up sheet(s))
Source features: 3. Distinct farm/tract close-up sheets: 3
Road labels visible on each sheet: [5, 5, 5]
Road-label compliance: PASS
Roads: ['Braxton Ln', 'Cortez Dr', 'Bonner Ave', 'State Rd S-38-172', 'Ellexlee Rd', 'Sheard Dr', 'Import Ave', 'Thrower Ln', 'Calain St', 'Big Phils Ct']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
