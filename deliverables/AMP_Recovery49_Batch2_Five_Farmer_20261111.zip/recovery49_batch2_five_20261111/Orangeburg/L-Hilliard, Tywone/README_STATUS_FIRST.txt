Tywone Hilliard: THREE 2024 FSA SOURCE FIELDS GEOREFERENCED; YEAR2 ENROLLMENT OPEN.
Source map1 Farm3873 Tract3895 Field4, source map2 Farm4261 Tract5953 Field2,
source map3 Farm960 Tract3812 Field1. All from scans matched to USGS NAIP imagery.
Year2 asks for Farms1064 and3826, not covered by these source PDF pages.
Approximate photo traces, not legal cadastral surveys.
One producer EPSG:4326 shapefile, one county topo map, three satellite close-up pages.
