Joe Hilliard 2024 FSA map Farm13859/Tract45814 Field36 (25.32 acres): SOURCE GEOREGISTERED.
Approximate geodesic trace 24.312 acres (-4.0%); 83 NAIP image correspondences; 1.18px RMSE.
Year2 target Field20 is absent from both available Joe FSA maps. FARMER REMAINS OPEN.
Field36 must not be relabeled as Field20. Other supplied map Farm6528 is separate.
One EPSG:4326 farmer source shapefile, one topo county map and one satellite field map.
This field is a photo-traced research approximation, NOT a legal survey.
