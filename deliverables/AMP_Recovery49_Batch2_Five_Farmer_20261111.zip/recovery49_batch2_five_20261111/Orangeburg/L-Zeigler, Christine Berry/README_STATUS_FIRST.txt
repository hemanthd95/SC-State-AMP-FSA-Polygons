Christine Berry Zeigler YEAR2 TARGET COMPLETED: Farm1271 Tract469 Field1, 10.51 FSA acres.
Source Farm1271 and Tract469 confirmed by direct visual inspection of original photographed FSA footer.
NAIP registration: 217 matches, 1.2803 pixel residual; mapped approximate area 11.1279 ac, difference +5.88%.
Field located in Orangeburg County from official census polygons; printed FSA office county ignored.
Research-only field geometry; NOT a cadastral or legal survey.
