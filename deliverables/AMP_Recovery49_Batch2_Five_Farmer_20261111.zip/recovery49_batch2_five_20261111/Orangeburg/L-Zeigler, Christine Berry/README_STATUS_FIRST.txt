Christine Berry Zeigler, Year2 Farm1271/Tract469/Field1: MAPPED
Georeferenced source 10.51ac, approximate trace 11.128ac (+5.9%).
Location grounded in 217 independent NAIP image matches, 1.28px residual and Arista/Baxley road geometry.
Physical Census county: Orangeburg. Source FSA printing county ignored.
EPSG:4326 shapefile and Weekley county topographic and road-labeled satellite PDFs.
Research planning polygon only; manually traced approximate interior field; not survey.
