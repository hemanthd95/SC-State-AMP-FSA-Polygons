SCSU AMP: Christine Berry Zeigler, Orangeburg County
Shapefile: ChristineBerryZeigler.shp/ (EPSG:4326; one record per accepted field)
County context map: ChristineBerryZeigler-CountyMap.pdf (topographic)
Farmer field map: ChristineBerryZeigler-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['State Rd S-38-692', 'Arista Rd', 'Oc 4439', 'Baxley Rd', 'State Rd S-38-1860']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
