SC State AMP Batch2 five-farmer GIS: Christine Berry Zeigler complete known Year2 field.
Tywone Hilliard has three non-enrolled 2024 source fields mapped; Year2 Farms1064/3826 missing.
Joe Hilliard has one SOURCE field (Farm13859/Tract45814/Field36) mapped; Year2 Field20 missing.
Calvin Blair and Javeiann Spann locations not accepted. Follow-up queue 43, down from 44.
All polygons approximate FSA photo traces; NOT legal surveys.
