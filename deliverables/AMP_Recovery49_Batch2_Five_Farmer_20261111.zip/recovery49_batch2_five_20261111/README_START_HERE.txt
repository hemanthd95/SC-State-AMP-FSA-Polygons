Batch2 five SC AMP farmers. Christine: source- and roster-matched Farm1271/Tract469/Field1, registered.
Tywone: 3 photographed-source FSA fields on other Farm IDs registered, NOT Year2 completed.
Joe, Calvin, Javeiann: source-only QA; no accepted enrolled field polygon yet.
GIS is approximate for research planning; not legal surveys; ignore FSA printed office counties.
