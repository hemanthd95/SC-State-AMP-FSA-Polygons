Batch2 SC State AMP FSA field mapping - five producers
1 registered approximate enrolled field (Christine Berry Zeigler); four other review folders NOT COMPLETED.
Christine includes Weekley EPSG:4326 farmer shapefile, county topographic PDF, road-labeled satellite field PDF.
Do not confuse strong FSA photo registration with confirming enrolled Farm/Tract/Field.
See Batch2_Five_Farmer_QA.csv for each outstanding blocker.
