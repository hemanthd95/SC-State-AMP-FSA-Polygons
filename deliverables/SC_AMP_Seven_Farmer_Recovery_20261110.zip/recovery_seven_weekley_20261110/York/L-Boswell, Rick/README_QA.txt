SCSU AMP: Rick Boswell, York County
Shapefile: RickBoswell.shp/ (EPSG:4326; one record per accepted field)
County context map: RickBoswell-CountyMap.pdf (topographic)
Farmer field map: RickBoswell-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Tom Joye Rd', 'State Rte 414', 'State Rd S-46-414', 'Garrett Landen Dr', 'Kerrington Way']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
