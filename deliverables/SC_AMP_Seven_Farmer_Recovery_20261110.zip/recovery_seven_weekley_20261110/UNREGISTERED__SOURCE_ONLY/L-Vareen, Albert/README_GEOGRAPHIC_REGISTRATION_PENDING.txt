SCSU AMP: Albert Vareen
Excel roster county: Marion
Excel address: 112 East End Street, Mullins SC 29574
Requested FSA identifiers: ['9652/7769/1']
Source: Albert vareen_FSA_Map.pdf, pages [1]
CURRENT STATUS: NO ACCEPTED FIELD GEOMETRY. NO SHAPEFILE GENERATED.
Why: Requested source Field1 is visually identified, but wide-area aerial registration has not confirmed the property. Do not treat a geocoded residence or PDF pixel polygon as a georeferenced field.
The source PDF pages are NOT georeferenced; do NOT import them as field boundaries.
The county printed in an FSA office PDF is ignored for physical-field decisions.
