SCSU AMP: Tyrease Riley
Excel roster county: Sumter
Excel address: 1033 Armour Hill Dr Pinewood SC 29125
Requested FSA identifiers: ['3603/848/1']
Source: Tyreese Riley_FSA Map.pdf, pages [1]
CURRENT STATUS: NO ACCEPTED FIELD GEOMETRY. NO SHAPEFILE GENERATED.
Why: Farm3603 Tract848 Field1 visible in source; a robust NAIP/Esri geographic image match remains unconfirmed.
The source PDF pages are NOT georeferenced; do NOT import them as field boundaries.
The county printed in an FSA office PDF is ignored for physical-field decisions.
