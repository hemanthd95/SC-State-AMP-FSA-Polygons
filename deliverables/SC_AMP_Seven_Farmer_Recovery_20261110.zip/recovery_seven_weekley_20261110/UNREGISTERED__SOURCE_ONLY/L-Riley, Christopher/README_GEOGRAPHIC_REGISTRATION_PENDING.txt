SCSU AMP: Christopher Riley
Excel roster county: Sumter
Excel address: 1095 Armour Hill Drive Pinewood SC 29125
Requested FSA identifiers: ['7832/5341/2']
Source: Christopher Riley FSAmap1.pdf, pages [2, 3]
CURRENT STATUS: NO ACCEPTED FIELD GEOMETRY. NO SHAPEFILE GENERATED.
Why: The source page for Farm7832 Tract5341 shows Fields 1,4,5 but not requested Field2. Field2 appears in source Tract5340, a different tract; do not substitute.
The source PDF pages are NOT georeferenced; do NOT import them as field boundaries.
The county printed in an FSA office PDF is ignored for physical-field decisions.
