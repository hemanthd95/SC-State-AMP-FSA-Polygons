SCSU AMP: Albert Vareen, Marion County
Shapefile: AlbertVareen.shp/ (EPSG:4326; one record per accepted field)
County context map: AlbertVareen-CountyMap.pdf (topographic)
Farmer field map: AlbertVareen-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Doctor Rd', 'State Rd S-34-29', 'Hoyt Rogers Rd', 'Glennies Dr', 'J L Dew Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
