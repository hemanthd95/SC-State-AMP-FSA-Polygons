SCSU AMP: Francena Ellis, Hampton County
Shapefile: FrancenaEllis.shp/ (EPSG:4326; one record per accepted field)
County context map: FrancenaEllis-CountyMap.pdf (topographic)
Farmer field map: FrancenaEllis-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Fishnetwork', 'Co Rd S-25-225', 'Grass Hill Rd', 'Co Rd S-25-64', 'Southern Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
