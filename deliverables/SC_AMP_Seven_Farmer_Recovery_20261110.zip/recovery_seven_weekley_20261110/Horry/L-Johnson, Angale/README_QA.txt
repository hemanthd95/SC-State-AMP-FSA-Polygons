SCSU AMP: Angale Johnson, Horry County
Shapefile: AngaleJohnson.shp/ (EPSG:4326; one record per accepted field)
County context map: AngaleJohnson-CountyMap.pdf (topographic)
Farmer field map: AngaleJohnson-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [4, 4]
Road-label compliance: PASS
Roads: ['Primrose Dr', 'Mamie Rd', 'Plainfield Rd', 'Tyler Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
