SCSU AMP: Charles Bright Jr., Colleton County
Shapefile: CharlesBrightJr.shp/ (EPSG:4326; one record per accepted field)
County context map: CharlesBrightJr-CountyMap.pdf (topographic)
Farmer field map: CharlesBrightJr-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Pine Hill Ln', 'Jo Rose Ln', 'Clinic Dr', 'Cornflower Ln', 'Monarch Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
