SCSU AMP / Charles Bright Jr.
Source Farm 2715, Tract 3022. Fields included: 2
STATUS: SOURCE_PARTIAL_NOT_YEAR2_COMPLETE
ENROLLMENT STATUS: No selected Field ID in Year2 master; source page1 also Fields 9,10,3; page2 is Tract3021
Only the source-labeled, georeferenced, acreage-checked field geometries were included.
Do not mistake this subset for a completed enrolled farmer when selection is missing.
WGS84 (EPSG:4326) farmer shapefile, topographic context and road-labeled satellite PDFs.
FSA administrative/printing county was ignored when determining physical location.
Geometries are approximate photo-source field outlines, NOT legal/cadastral surveys.
