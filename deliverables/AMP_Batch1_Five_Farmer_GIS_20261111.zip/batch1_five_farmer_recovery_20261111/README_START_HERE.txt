SC STATE AMP - BATCH 1 OF 5 FARMERS
New georeferenced source-field GIS for Arthur Cobbs, Charles Bright Jr., Joseph Gadson.
Existing separate per-farmer mapped GIS for Jasper Summers and Margaret Berry carried forward unchanged.
Year2 status: Arthur Cobbs source Field1 mapped, Year2 selected Field ID blank; all five remain enrollment-QA open.
Some FSA source fields are NOT INCLUDED because not yet digitized/area verified.
Use Batch1_Farmer_QA.csv and each farmer's status README. Photo-source boundaries are not surveys.
