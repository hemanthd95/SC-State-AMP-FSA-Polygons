SC STATE AMP - BATCH1 FIVE-FARMER GIS (UPDATED WITH ADDITIONAL TRACTS)
Charles Bright Jr.: Farm2715/Tract3021 Fields4/7 and Tract3022 Field2, other fields remain unresolved.
Joseph Gadson: Farm4547/Tract4482 source Fields3/4 georegistered, enrollment IDs blank.
Arthur Cobbs: Farm548/Tract295 Field1 source mapped, enrollment selected Field ID blank.
Jasper Summers: Farm13709 Tract45514 Fields8/17 and Tract45512 Fields16/27, plus older Farm13653.
Margaret Berry: Farm10939 Field3 and Farm11782 Field13; earlier 74% acreage mismatch unresolved.
Zero of five farmers administratively closed; source-registered geometry is not a legal survey.
