SCSU AMP: Margaret Berry, Orangeburg County
Shapefile: MargaretBerry.shp/ (EPSG:4326; one record per accepted field)
County context map: MargaretBerry-CountyMap.pdf (topographic)
Farmer field map: MargaretBerry-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [4, 5]
Road-label compliance: PASS
Roads: ['Oc 4221', 'Nassau Dr', 'Oc 4467', 'Kangaroo Ct', 'State Rd S-38-168']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
