Margaret Berry - retained existing registered polygons without altering geometry.
STATUS: PARTIAL_NOT_CLOSED
Farm10939 Field3 mapped; older Farm11782 Field13 area differs substantially from 7.53 FSA acres
Do not count as fully completed based on presence of shapefile alone.
