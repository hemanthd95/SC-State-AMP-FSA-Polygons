Margaret Berry (also spelled Mageret): TWO mapped Farm IDs; ONE open acreage QA.
NEW: Farm10939 Tract43399 Field3 source 1.57ac; independent NAIP registration 163 inliers, 0.872px RMSE; geodetic trace 1.566 acres.
EXISTING: Farm11782 Tract6230 Field13 previous source 7.53ac vs approx polygon 13.11ac; flagged, NOT accepted as final area.
One producer shapefile with both field features; one topo county map; two satellite close-up sheets.
Do not mark this farmer COMPLETED until the 11782 discrepancy is resolved.
Source map county is not used as a farm location anchor.
