Jasper Summers - retained existing registered polygons without altering geometry.
STATUS: PARTIAL_NOT_CLOSED
Farm13709 Fields8/17 mapped; enrollment field blank and Tract45512 Fields16/27 remain unregistered
Do not count as fully completed based on presence of shapefile alone.
