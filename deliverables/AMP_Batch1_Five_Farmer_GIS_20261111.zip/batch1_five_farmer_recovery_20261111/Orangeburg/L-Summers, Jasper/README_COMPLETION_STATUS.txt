Jasper Summers - Batch1 extended source mapping
STATUS: SOURCE FIELDS GEOGRAPHICALLY REGISTERED, ENROLLMENT MATCH OPEN.
Included source: 13709 Tract45512, page 3
New source fields: 16,27
Remaining exceptions: Year2 master selects Farm13709 but field number blank; source page1 Tract45514 Fields8 and17 already mapped.
All historical georeferenced fields retained. WGS84 producer shapefile; one county topo map; multiple satellite close-up pages.
Printed FSA administrative county not used to locate field. Not a cadastral survey.
