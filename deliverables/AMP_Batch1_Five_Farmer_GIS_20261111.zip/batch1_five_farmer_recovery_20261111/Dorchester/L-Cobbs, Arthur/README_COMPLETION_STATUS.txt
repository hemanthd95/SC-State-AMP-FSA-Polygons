SCSU AMP / Arthur Cobbs
Source Farm 548, Tract 295. Fields included: 1
STATUS: SOURCE_FIELD_MAPPED_YEAR2_ENROLLED_FIELD_UNSPECIFIED
ENROLLMENT STATUS: Year2 Farm548, source Farm548/Tract295 Field1; only labeled cropped field on source map
Only the source-labeled, georeferenced, acreage-checked field geometries were included.
Do not mistake this subset for a completed enrolled farmer when selection is missing.
WGS84 (EPSG:4326) farmer shapefile, topographic context and road-labeled satellite PDFs.
FSA administrative/printing county was ignored when determining physical location.
Geometries are approximate photo-source field outlines, NOT legal/cadastral surveys.
