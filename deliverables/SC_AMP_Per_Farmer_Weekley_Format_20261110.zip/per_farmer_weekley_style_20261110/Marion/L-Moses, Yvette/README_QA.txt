SCSU AMP: Yvette Moses, Marion County
Shapefile: YvetteMoses.shp/ (EPSG:4326, one feature per previously accepted field)
County map: YvetteMoses-CountyMap.pdf (topographic)
Field map: YvetteMoses-FieldMap.pdf (satellite + named road labels)
Registered feature count: 4
Independently named roads visible: 5 -> ['Beachmon Ct', 'Runabout Rd', 'Haven Ct', 'State Rd S-34-476', 'Willie Hodge Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
