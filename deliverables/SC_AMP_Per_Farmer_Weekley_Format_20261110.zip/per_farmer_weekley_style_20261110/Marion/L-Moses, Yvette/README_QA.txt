SCSU AMP: Yvette Moses, Marion County
Shapefile: YvetteMoses.shp/ (EPSG:4326; one record per accepted field)
County context map: YvetteMoses-CountyMap.pdf (topographic)
Farmer field map: YvetteMoses-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 4. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Beachmon Ct', 'Runabout Rd', 'Haven Ct', 'State Rd S-34-476', 'Willie Hodge Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
