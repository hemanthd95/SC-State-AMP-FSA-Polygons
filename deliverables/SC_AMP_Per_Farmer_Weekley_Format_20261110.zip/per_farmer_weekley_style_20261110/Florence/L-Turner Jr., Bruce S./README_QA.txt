SCSU AMP: Bruce S. Turner Jr., Florence County
Shapefile: BruceSTurnerJr.shp/ (EPSG:4326, one feature per previously accepted field)
County map: BruceSTurnerJr-CountyMap.pdf (topographic)
Field map: BruceSTurnerJr-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Cherry Johnson Rd', 'Jenkins Nowlin Rd', 'Nowlin Cir']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
