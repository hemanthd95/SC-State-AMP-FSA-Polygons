SCSU AMP: Bruce S. Turner Jr., Florence County
Shapefile: BruceSTurnerJr.shp/ (EPSG:4326; one record per accepted field)
County context map: BruceSTurnerJr-CountyMap.pdf (topographic)
Farmer field map: BruceSTurnerJr-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Cherry Johnson Rd', 'Jenkins Nowlin Rd', 'Nowlin Cir']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
