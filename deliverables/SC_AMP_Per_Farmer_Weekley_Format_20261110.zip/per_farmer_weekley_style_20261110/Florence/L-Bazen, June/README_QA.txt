SCSU AMP: June Bazen, Florence County
Shapefile: JuneBazen.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JuneBazen-CountyMap.pdf (topographic)
Field map: JuneBazen-FieldMap.pdf (satellite + named road labels)
Registered feature count: 4
Independently named roads visible: 5 -> ['Hoyt Rd', 'Lockwood Ln', 'Sheminally Rd', 'State Rd S-21-49', 'Beaudock Ln']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
