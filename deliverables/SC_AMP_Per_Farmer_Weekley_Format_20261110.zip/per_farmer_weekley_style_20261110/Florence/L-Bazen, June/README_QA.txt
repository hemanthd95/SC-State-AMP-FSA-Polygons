SCSU AMP: June Bazen, Florence County
Shapefile: JuneBazen.shp/ (EPSG:4326; one record per accepted field)
County context map: JuneBazen-CountyMap.pdf (topographic)
Farmer field map: JuneBazen-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 4. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [5, 5]
Road-label compliance: PASS
Roads: ['Hoyt Rd', 'Lockwood Ln', 'Sheminally Rd', 'State Rd S-21-49', 'Beaudock Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
