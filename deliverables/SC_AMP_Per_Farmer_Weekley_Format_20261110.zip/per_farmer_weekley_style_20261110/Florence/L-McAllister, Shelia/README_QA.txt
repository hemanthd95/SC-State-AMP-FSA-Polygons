SCSU AMP: Shelia McAllister, Florence County
Shapefile: SheliaMcAllister.shp/ (EPSG:4326, one feature per previously accepted field)
County map: SheliaMcAllister-CountyMap.pdf (topographic)
Field map: SheliaMcAllister-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 5 -> ['Java Rd', 'Poor Farm Rd', 'State Rd S-21-552', 'State Rd S-21-1463', 'Callie Young Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
