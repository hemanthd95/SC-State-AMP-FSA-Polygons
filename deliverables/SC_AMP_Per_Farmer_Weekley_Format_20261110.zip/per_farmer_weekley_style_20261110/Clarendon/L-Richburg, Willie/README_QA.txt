SCSU AMP: Willie Richburg, Clarendon County
Shapefile: WillieRichburg.shp/ (EPSG:4326, one feature per previously accepted field)
County map: WillieRichburg-CountyMap.pdf (topographic)
Field map: WillieRichburg-FieldMap.pdf (satellite + named road labels)
Registered feature count: 4
Independently named roads visible: 2 -> ['State Rd S-14-14', 'Reverend J W Carter Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
