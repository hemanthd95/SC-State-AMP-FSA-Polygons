SCSU AMP: Willie Richburg, Clarendon County
Shapefile: WillieRichburg.shp/ (EPSG:4326; one record per accepted field)
County context map: WillieRichburg-CountyMap.pdf (topographic)
Farmer field map: WillieRichburg-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 4. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [4, 2]
Road-label compliance: PASS
Roads: ['State Rd S-14-14', 'Reverend J W Carter Rd', 'State Rd S-14-514', '20th Century Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
