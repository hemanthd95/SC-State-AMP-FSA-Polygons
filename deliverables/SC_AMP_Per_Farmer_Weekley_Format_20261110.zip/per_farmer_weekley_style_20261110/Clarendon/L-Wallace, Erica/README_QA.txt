SCSU AMP: Erica Wallace, Clarendon County
Shapefile: EricaWallace.shp/ (EPSG:4326; one record per accepted field)
County context map: EricaWallace-CountyMap.pdf (topographic)
Farmer field map: EricaWallace-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Sterling Dr', 'State Rd S-14-57', 'Furse Rd', 'Silver Rd', 'State Rd S-14-79']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
