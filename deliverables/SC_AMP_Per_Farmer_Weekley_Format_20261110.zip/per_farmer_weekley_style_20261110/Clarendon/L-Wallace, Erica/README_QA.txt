SCSU AMP: Erica Wallace, Clarendon County
Shapefile: EricaWallace.shp/ (EPSG:4326, one feature per previously accepted field)
County map: EricaWallace-CountyMap.pdf (topographic)
Field map: EricaWallace-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Sterling Dr', 'State Rd S-14-57', 'Furse Rd', 'Silver Rd', 'State Rd S-14-79']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
