SCSU AMP: Bryan Green, Clarendon County
Shapefile: BryanGreen.shp/ (EPSG:4326; one record per accepted field)
County context map: BryanGreen-CountyMap.pdf (topographic)
Farmer field map: BryanGreen-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Sterling Dr', 'State Rd S-14-57', 'Furse Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
