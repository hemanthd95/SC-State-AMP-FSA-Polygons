SCSU AMP: Bryan Green, Clarendon County
Shapefile: BryanGreen.shp/ (EPSG:4326, one feature per previously accepted field)
County map: BryanGreen-CountyMap.pdf (topographic)
Field map: BryanGreen-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 3 -> ['Sterling Dr', 'State Rd S-14-57', 'Furse Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
