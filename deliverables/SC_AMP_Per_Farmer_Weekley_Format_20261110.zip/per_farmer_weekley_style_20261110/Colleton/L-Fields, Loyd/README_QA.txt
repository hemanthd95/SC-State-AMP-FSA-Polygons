SCSU AMP: Loyd Fields, Colleton County
Shapefile: LoydFields.shp/ (EPSG:4326, one feature per previously accepted field)
County map: LoydFields-CountyMap.pdf (topographic)
Field map: LoydFields-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Pynes Comm Rd', 'State Rd S-15-535', 'Pynes Community Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
