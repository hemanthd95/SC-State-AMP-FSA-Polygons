SCSU AMP: Loyd Fields, Colleton County
Shapefile: LoydFields.shp/ (EPSG:4326; one record per accepted field)
County context map: LoydFields-CountyMap.pdf (topographic)
Farmer field map: LoydFields-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Pynes Comm Rd', 'State Rd S-15-535', 'Pynes Community Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
