SCSU AMP: Aretha Bennett, Colleton County
Shapefile: ArethaBennett.shp/ (EPSG:4326, one feature per previously accepted field)
County map: ArethaBennett-CountyMap.pdf (topographic)
Field map: ArethaBennett-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Crawford Ln', 'Abbey Ln', 'Apostle Ln', 'Valhalla Way', 'Smalls Ct']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
