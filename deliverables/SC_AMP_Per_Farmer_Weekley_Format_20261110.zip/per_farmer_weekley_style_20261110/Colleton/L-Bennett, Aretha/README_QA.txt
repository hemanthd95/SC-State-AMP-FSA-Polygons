SCSU AMP: Aretha Bennett, Colleton County
Shapefile: ArethaBennett.shp/ (EPSG:4326; one record per accepted field)
County context map: ArethaBennett-CountyMap.pdf (topographic)
Farmer field map: ArethaBennett-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Crawford Ln', 'Abbey Ln', 'Apostle Ln', 'Valhalla Way', 'Smalls Ct']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
