SCSU AMP: Julian Ramsue, Berkeley County
Shapefile: JulianRamsue.shp/ (EPSG:4326; one record per accepted field)
County context map: JulianRamsue-CountyMap.pdf (topographic)
Farmer field map: JulianRamsue-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Game Rd', 'Unity Rd', 'Bo Cat Aly', 'Isiah Ln', 'Four Oak Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
