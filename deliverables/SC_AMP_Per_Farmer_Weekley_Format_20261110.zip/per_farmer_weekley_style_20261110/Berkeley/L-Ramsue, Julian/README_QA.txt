SCSU AMP: Julian Ramsue, Berkeley County
Shapefile: JulianRamsue.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JulianRamsue-CountyMap.pdf (topographic)
Field map: JulianRamsue-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 5 -> ['Game Rd', 'Unity Rd', 'Bo Cat Aly', 'Isiah Ln', 'Four Oak Ln']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
