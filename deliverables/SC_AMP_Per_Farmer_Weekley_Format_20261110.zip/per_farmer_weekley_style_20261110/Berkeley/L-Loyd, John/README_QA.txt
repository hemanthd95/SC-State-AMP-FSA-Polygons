SCSU AMP: John Loyd, Berkeley County
Shapefile: JohnLoyd.shp/ (EPSG:4326; one record per accepted field)
County context map: JohnLoyd-CountyMap.pdf (topographic)
Farmer field map: JohnLoyd-FieldMap.pdf (2 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 2
Road labels visible on each sheet: [5, 5]
Road-label compliance: PASS
Roads: ['Lloyd Ln', 'Rego Ln', 'Brentwood Ct', 'Welcome Ln', 'Karlton Ln', 'Friendly Hill Ln', 'Hard Pinch Rd', 'State Rd S-8-359', 'Rufus Rd', 'Weston Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
