SCSU AMP: John Loyd, Berkeley County
Shapefile: JohnLoyd.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JohnLoyd-CountyMap.pdf (topographic)
Field map: JohnLoyd-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 5 -> ['Friendly Hill Ln', 'Hard Pinch Rd', 'State Rd S-8-359', 'McNeil Ln', 'Stacy Ln']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
