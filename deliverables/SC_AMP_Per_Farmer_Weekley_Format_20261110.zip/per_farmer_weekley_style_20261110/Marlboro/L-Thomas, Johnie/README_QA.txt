SCSU AMP: Johnie Thomas, Marlboro County
Shapefile: JohnieThomas.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JohnieThomas-CountyMap.pdf (topographic)
Field map: JohnieThomas-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Co Rd 97', 'Co Rd 113', 'Billy Wallace Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
