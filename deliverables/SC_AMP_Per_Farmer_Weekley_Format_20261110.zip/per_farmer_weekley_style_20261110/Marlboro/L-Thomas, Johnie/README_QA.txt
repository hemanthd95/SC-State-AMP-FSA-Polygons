SCSU AMP: Johnie Thomas, Marlboro County
Shapefile: JohnieThomas.shp/ (EPSG:4326; one record per accepted field)
County context map: JohnieThomas-CountyMap.pdf (topographic)
Farmer field map: JohnieThomas-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Co Rd 97', 'Co Rd 113', 'Billy Wallace Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
