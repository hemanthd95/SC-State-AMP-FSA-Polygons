SCSU AMP: Chris Berlin, Williamsburg County
Shapefile: ChrisBerlin.shp/ (EPSG:4326, one feature per previously accepted field)
County map: ChrisBerlin-CountyMap.pdf (topographic)
Field map: ChrisBerlin-FieldMap.pdf (satellite + named road labels)
Registered feature count: 7
Independently named roads visible: 5 -> ['Co Rd S-45-121', 'Wildflower Rd', 'Mockingbird Ln', 'Co Rd S-45-483', 'Country Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
