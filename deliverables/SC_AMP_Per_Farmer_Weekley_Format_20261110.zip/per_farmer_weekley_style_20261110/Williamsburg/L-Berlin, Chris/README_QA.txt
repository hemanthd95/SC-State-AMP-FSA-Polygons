SCSU AMP: Chris Berlin, Williamsburg County
Shapefile: ChrisBerlin.shp/ (EPSG:4326; one record per accepted field)
County context map: ChrisBerlin-CountyMap.pdf (topographic)
Farmer field map: ChrisBerlin-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 7. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Co Rd S-45-121', 'Wildflower Rd', 'Mockingbird Ln', 'Co Rd S-45-483', 'Country Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
