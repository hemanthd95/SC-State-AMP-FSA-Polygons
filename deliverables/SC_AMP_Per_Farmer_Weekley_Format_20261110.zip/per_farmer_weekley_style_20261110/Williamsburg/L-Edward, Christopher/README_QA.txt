SCSU AMP: Christopher Edward, Williamsburg County
Shapefile: ChristopherEdward.shp/ (EPSG:4326, one feature per previously accepted field)
County map: ChristopherEdward-CountyMap.pdf (topographic)
Field map: ChristopherEdward-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 4 -> ['McCullough Loop', 'Co Rd S-45-719', 'Kit Ave', 'Ike Mitchum Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
