SCSU AMP: John Lee, Jasper County
Shapefile: JohnLee.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JohnLee-CountyMap.pdf (topographic)
Field map: JohnLee-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 5 -> ['Tye Branch Rd', 'Lee Lawyer Rd', 'Tye Branch Spr', 'Taylor Dr', 'Richard Pollins Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
