SCSU AMP: John Lee, Jasper County
Shapefile: JohnLee.shp/ (EPSG:4326; one record per accepted field)
County context map: JohnLee-CountyMap.pdf (topographic)
Farmer field map: JohnLee-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Tye Branch Rd', 'Lee Lawyer Rd', 'Tye Branch Spr', 'Taylor Dr', 'Richard Pollins Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
