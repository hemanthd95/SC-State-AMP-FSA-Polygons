SCSU AMP: Derick Muhammed, Jasper County
Shapefile: DerickMuhammed.shp/ (EPSG:4326; one record per accepted field)
County context map: DerickMuhammed-CountyMap.pdf (topographic)
Farmer field map: DerickMuhammed-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Levy Rd', 'S 27-34', 'Marble Rd', 'State Rd S-27-308', 'Central Ave']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
