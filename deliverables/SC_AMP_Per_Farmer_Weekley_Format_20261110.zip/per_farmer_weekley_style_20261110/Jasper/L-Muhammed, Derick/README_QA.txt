SCSU AMP: Derick Muhammed, Jasper County
Shapefile: DerickMuhammed.shp/ (EPSG:4326, one feature per previously accepted field)
County map: DerickMuhammed-CountyMap.pdf (topographic)
Field map: DerickMuhammed-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Levy Rd', 'S 27-34', 'Marble Rd', 'State Rd S-27-308', 'Central Ave']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
