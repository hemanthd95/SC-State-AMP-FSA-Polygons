SCSU AMP: Mageret Berry, Orangeburg County
Shapefile: MageretBerry.shp/ (EPSG:4326, one feature per previously accepted field)
County map: MageretBerry-CountyMap.pdf (topographic)
Field map: MageretBerry-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Oc 4467', 'Kangaroo Ct', 'Oc 4221', 'Nassau Dr', 'State Rd S-38-168']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
