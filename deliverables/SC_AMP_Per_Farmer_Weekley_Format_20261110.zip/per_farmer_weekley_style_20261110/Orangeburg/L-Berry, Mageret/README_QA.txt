SCSU AMP: Mageret Berry, Orangeburg County
Shapefile: MageretBerry.shp/ (EPSG:4326; one record per accepted field)
County context map: MageretBerry-CountyMap.pdf (topographic)
Farmer field map: MageretBerry-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Oc 4467', 'Kangaroo Ct', 'Oc 4221', 'Nassau Dr', 'State Rd S-38-168']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
