SCSU AMP: Tywone Hilliard, Orangeburg County
Shapefile: TywoneHilliard.shp/ (EPSG:4326, one feature per previously accepted field)
County map: TywoneHilliard-CountyMap.pdf (topographic)
Field map: TywoneHilliard-FieldMap.pdf (satellite + named road labels)
Registered feature count: 3
Independently named roads visible: 5 -> ['Braxton Ln', 'Cortez Dr', 'Vernetha Ln', 'Bonner Ave', 'Ellexlee Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
