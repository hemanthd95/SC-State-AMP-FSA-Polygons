SCSU AMP: Rosa Berry, Orangeburg County
Shapefile: RosaBerry.shp/ (EPSG:4326, one feature per previously accepted field)
County map: RosaBerry-CountyMap.pdf (topographic)
Field map: RosaBerry-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 4 -> ['Boyd Rd', 'O C 4109', 'State Rd S-38-198', 'Tradewinds St']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
