SCSU AMP: Rosa Berry, Orangeburg County
Shapefile: RosaBerry.shp/ (EPSG:4326; one record per accepted field)
County context map: RosaBerry-CountyMap.pdf (topographic)
Farmer field map: RosaBerry-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [4]
Road-label compliance: PASS
Roads: ['Boyd Rd', 'O C 4109', 'State Rd S-38-198', 'Tradewinds St']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
