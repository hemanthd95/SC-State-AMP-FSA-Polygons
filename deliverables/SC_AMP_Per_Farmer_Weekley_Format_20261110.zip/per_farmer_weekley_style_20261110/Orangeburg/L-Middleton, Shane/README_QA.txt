SCSU AMP: Shane Middleton, Orangeburg County
Shapefile: ShaneMiddleton.shp/ (EPSG:4326, one feature per previously accepted field)
County map: ShaneMiddleton-CountyMap.pdf (topographic)
Field map: ShaneMiddleton-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Checkerberry Rd', 'Checkerberry Ct', 'Richardson St', 'County Line Rd', 'State Rd S-8-59']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
