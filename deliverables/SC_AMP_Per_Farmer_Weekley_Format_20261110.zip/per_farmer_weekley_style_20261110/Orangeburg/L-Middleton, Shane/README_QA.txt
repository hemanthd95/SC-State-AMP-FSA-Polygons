SCSU AMP: Shane Middleton, Orangeburg County
Shapefile: ShaneMiddleton.shp/ (EPSG:4326; one record per accepted field)
County context map: ShaneMiddleton-CountyMap.pdf (topographic)
Farmer field map: ShaneMiddleton-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Checkerberry Rd', 'Checkerberry Ct', 'Richardson St', 'County Line Rd', 'State Rd S-8-59']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
