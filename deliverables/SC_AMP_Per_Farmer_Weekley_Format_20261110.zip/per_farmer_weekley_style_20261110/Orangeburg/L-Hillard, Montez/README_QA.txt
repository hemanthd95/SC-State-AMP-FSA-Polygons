SCSU AMP: Montez Hillard, Orangeburg County
Shapefile: MontezHillard.shp/ (EPSG:4326, one feature per previously accepted field)
County map: MontezHillard-CountyMap.pdf (topographic)
Field map: MontezHillard-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Cortez Dr', 'Vernetha Ln', 'Braxton Ln', 'Bonner Ave', 'State Rd S-38-172']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
