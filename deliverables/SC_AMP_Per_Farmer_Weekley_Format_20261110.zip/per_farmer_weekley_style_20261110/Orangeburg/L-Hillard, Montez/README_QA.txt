SCSU AMP: Montez Hillard, Orangeburg County
Shapefile: MontezHillard.shp/ (EPSG:4326; one record per accepted field)
County context map: MontezHillard-CountyMap.pdf (topographic)
Farmer field map: MontezHillard-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Cortez Dr', 'Vernetha Ln', 'Braxton Ln', 'Bonner Ave', 'State Rd S-38-172']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
