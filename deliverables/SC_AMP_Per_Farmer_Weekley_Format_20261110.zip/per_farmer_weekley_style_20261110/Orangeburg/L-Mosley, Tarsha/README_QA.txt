SCSU AMP: Tarsha Mosley, Orangeburg County
Shapefile: TarshaMosley.shp/ (EPSG:4326; one record per accepted field)
County context map: TarshaMosley-CountyMap.pdf (topographic)
Farmer field map: TarshaMosley-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['State Rd S-38-811', 'Hillsboro Rd', 'Livingston Ter NW', 'Way Dr', 'Crescent Oaks Ct']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
