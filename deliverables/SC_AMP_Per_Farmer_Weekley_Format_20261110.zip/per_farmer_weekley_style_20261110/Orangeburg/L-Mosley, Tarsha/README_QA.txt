SCSU AMP: Tarsha Mosley, Orangeburg County
Shapefile: TarshaMosley.shp/ (EPSG:4326, one feature per previously accepted field)
County map: TarshaMosley-CountyMap.pdf (topographic)
Field map: TarshaMosley-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['State Rd S-38-811', 'Hillsboro Rd', 'Livingston Ter NW', 'Way Dr', 'Crescent Oaks Ct']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
