SCSU AMP: Bruce Jenkins, Orangeburg County
Shapefile: BruceJenkins.shp/ (EPSG:4326; one record per accepted field)
County context map: BruceJenkins-CountyMap.pdf (topographic)
Farmer field map: BruceJenkins-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 2. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['State Rd S-38-92', 'Winter Creek Rd', 'Ebenezer Rd', 'Jenkins Rd', 'Waymans Dr']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
