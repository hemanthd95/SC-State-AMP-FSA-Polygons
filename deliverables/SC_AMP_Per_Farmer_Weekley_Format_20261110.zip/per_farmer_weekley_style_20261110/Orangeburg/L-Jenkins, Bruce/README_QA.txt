SCSU AMP: Bruce Jenkins, Orangeburg County
Shapefile: BruceJenkins.shp/ (EPSG:4326, one feature per previously accepted field)
County map: BruceJenkins-CountyMap.pdf (topographic)
Field map: BruceJenkins-FieldMap.pdf (satellite + named road labels)
Registered feature count: 2
Independently named roads visible: 5 -> ['State Rd S-38-92', 'Winter Creek Rd', 'Ebenezer Rd', 'Jenkins Rd', 'Waymans Dr']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
