SCSU AMP: Robert Seaberry, Orangeburg County
Shapefile: RobertSeaberry.shp/ (EPSG:4326; one record per accepted field)
County context map: RobertSeaberry-CountyMap.pdf (topographic)
Farmer field map: RobertSeaberry-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Demo Ln', 'Co Rd O C - 3367', 'State Rd S-38-82', 'Pinewood Rd', 'Parlerville Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
