SCSU AMP: Robert Seaberry, Orangeburg County
Shapefile: RobertSeaberry.shp/ (EPSG:4326, one feature per previously accepted field)
County map: RobertSeaberry-CountyMap.pdf (topographic)
Field map: RobertSeaberry-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Demo Ln', 'Co Rd O C - 3367', 'State Rd S-38-82', 'Pinewood Rd', 'Parlerville Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
