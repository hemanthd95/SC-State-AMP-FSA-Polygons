SCSU AMP: Jasper Summers, Orangeburg County
Shapefile: JasperSummers.shp/ (EPSG:4326; one record per accepted field)
County context map: JasperSummers-CountyMap.pdf (topographic)
Farmer field map: JasperSummers-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['O C 4148', 'Hollyhock Rd', 'Jerry Summers Dr', 'Middle Rd', 'O C 4147']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
