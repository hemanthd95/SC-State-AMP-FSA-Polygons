SCSU AMP: Jasper Summers, Orangeburg County
Shapefile: JasperSummers.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JasperSummers-CountyMap.pdf (topographic)
Field map: JasperSummers-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['O C 4148', 'Hollyhock Rd', 'Jerry Summers Dr', 'Middle Rd', 'O C 4147']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
