SCSU AMP: Veronica Hodges, Orangeburg County
Shapefile: VeronicaHodges.shp/ (EPSG:4326, one feature per previously accepted field)
County map: VeronicaHodges-CountyMap.pdf (topographic)
Field map: VeronicaHodges-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['O C 4338', 'Downing Dr', 'Greywood Dr', 'State Rd S-38-1691', 'O C 4151']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
