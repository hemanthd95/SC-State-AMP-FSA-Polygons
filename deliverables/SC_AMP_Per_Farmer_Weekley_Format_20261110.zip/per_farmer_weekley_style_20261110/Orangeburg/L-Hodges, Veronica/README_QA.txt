SCSU AMP: Veronica Hodges, Orangeburg County
Shapefile: VeronicaHodges.shp/ (EPSG:4326; one record per accepted field)
County context map: VeronicaHodges-CountyMap.pdf (topographic)
Farmer field map: VeronicaHodges-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['O C 4338', 'Downing Dr', 'Greywood Dr', 'State Rd S-38-1691', 'O C 4151']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
