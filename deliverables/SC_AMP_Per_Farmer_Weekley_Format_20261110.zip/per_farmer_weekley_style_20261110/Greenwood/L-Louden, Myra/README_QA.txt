SCSU AMP: Myra Louden, Greenwood County
Shapefile: MyraLouden.shp/ (EPSG:4326, one feature per previously accepted field)
County map: MyraLouden-CountyMap.pdf (topographic)
Field map: MyraLouden-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 2 -> ['Breezewood Rd', 'State Rd S-24-375']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
