SCSU AMP: Rick Boswell, York County
Shapefile: RickBoswell.shp/ (EPSG:4326, one feature per previously accepted field)
County map: RickBoswell-CountyMap.pdf (topographic)
Field map: RickBoswell-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Tom Joye Rd', 'State Rte 414', 'State Rd S-46-414', 'Garrett Landen Dr', 'Kerrington Way']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
