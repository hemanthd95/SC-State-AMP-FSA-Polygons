SCSU AMP: John Brabham, Bamberg County
Shapefile: JohnBrabham.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JohnBrabham-CountyMap.pdf (topographic)
Field map: JohnBrabham-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 2 -> ['Semonole Rd', 'Persimmon Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
