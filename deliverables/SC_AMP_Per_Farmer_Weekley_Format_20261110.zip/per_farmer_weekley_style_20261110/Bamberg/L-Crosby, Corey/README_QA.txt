SCSU AMP: Corey Crosby, Bamberg County
Shapefile: CoreyCrosby.shp/ (EPSG:4326, one feature per previously accepted field)
County map: CoreyCrosby-CountyMap.pdf (topographic)
Field map: CoreyCrosby-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Semonole Rd', 'Persimmon Rd', 'Seminole Trl']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
