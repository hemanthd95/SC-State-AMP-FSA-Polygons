SCSU AMP: Corey Crosby, Bamberg County
Shapefile: CoreyCrosby.shp/ (EPSG:4326; one record per accepted field)
County context map: CoreyCrosby-CountyMap.pdf (topographic)
Farmer field map: CoreyCrosby-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Semonole Rd', 'Persimmon Rd', 'Seminole Trl']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
