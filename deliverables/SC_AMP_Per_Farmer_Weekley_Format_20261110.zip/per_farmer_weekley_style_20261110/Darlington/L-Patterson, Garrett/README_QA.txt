SCSU AMP: Garrett Patterson, Darlington County
Shapefile: GarrettPatterson.shp/ (EPSG:4326, one feature per previously accepted field)
County map: GarrettPatterson-CountyMap.pdf (topographic)
Field map: GarrettPatterson-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 2 -> ['W Lynches River Rd', 'Hennery Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
