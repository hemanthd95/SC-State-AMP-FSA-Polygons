SCSU AMP: Anthony Jackson, Darlington County
Shapefile: AnthonyJackson.shp/ (EPSG:4326, one feature per previously accepted field)
County map: AnthonyJackson-CountyMap.pdf (topographic)
Field map: AnthonyJackson-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Quietude Rd', 'E St Paul Rd', 'Twins Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
