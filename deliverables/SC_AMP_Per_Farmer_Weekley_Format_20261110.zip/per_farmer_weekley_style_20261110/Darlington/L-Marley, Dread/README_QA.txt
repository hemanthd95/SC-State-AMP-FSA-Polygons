SCSU AMP: Dread Marley, Darlington County
Shapefile: DreadMarley.shp/ (EPSG:4326, one feature per previously accepted field)
County map: DreadMarley-CountyMap.pdf (topographic)
Field map: DreadMarley-FieldMap.pdf (satellite + named road labels)
Registered feature count: 4
Independently named roads visible: 3 -> ['Quietude Rd', 'Twins Rd', 'E St Paul Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
