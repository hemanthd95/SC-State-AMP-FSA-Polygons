SCSU AMP: Dread Marley, Darlington County
Shapefile: DreadMarley.shp/ (EPSG:4326; one record per accepted field)
County context map: DreadMarley-CountyMap.pdf (topographic)
Farmer field map: DreadMarley-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 4. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [3]
Road-label compliance: PASS
Roads: ['Quietude Rd', 'Twins Rd', 'E St Paul Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
