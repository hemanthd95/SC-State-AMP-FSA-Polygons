SCSU AMP: Marva Jackson, Darlington County
Shapefile: MarvaJackson.shp/ (EPSG:4326; one record per accepted field)
County context map: MarvaJackson-CountyMap.pdf (topographic)
Farmer field map: MarvaJackson-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 3. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [2]
Road-label compliance: PASS
Roads: ['Faith Rd', 'Bethel Rd']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
