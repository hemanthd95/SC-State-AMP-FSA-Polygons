SCSU AMP: Marva Jackson, Darlington County
Shapefile: MarvaJackson.shp/ (EPSG:4326, one feature per previously accepted field)
County map: MarvaJackson-CountyMap.pdf (topographic)
Field map: MarvaJackson-FieldMap.pdf (satellite + named road labels)
Registered feature count: 3
Independently named roads visible: 2 -> ['Faith Rd', 'Bethel Rd']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
