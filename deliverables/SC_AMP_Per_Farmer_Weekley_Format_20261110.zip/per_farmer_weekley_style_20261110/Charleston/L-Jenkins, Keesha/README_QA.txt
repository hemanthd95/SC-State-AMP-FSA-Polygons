SCSU AMP: Keesha Jenkins, Charleston County
Shapefile: KeeshaJenkins.shp/ (EPSG:4326, one feature per previously accepted field)
County map: KeeshaJenkins-CountyMap.pdf (topographic)
Field map: KeeshaJenkins-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Chandler Rd', 'State Rd S-10-1453', 'Gold Ln', 'Tommy Ln', 'Secretariat Run']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
