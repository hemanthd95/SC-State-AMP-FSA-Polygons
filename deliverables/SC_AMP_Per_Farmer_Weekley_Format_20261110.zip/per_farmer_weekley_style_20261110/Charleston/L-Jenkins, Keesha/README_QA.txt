SCSU AMP: Keesha Jenkins, Charleston County
Shapefile: KeeshaJenkins.shp/ (EPSG:4326; one record per accepted field)
County context map: KeeshaJenkins-CountyMap.pdf (topographic)
Farmer field map: KeeshaJenkins-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Chandler Rd', 'State Rd S-10-1453', 'Gold Ln', 'Tommy Ln', 'Secretariat Run']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
