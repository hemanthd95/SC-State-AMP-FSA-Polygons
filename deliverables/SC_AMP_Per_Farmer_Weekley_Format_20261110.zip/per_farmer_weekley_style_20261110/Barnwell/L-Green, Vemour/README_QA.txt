SCSU AMP: Vemour Green, Barnwell County
Shapefile: VemourGreen.shp/ (EPSG:4326, one feature per previously accepted field)
County map: VemourGreen-CountyMap.pdf (topographic)
Field map: VemourGreen-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Phyllis St', 'Youngblood Rd', 'Dicks St', 'E Charleston St', 'Beck St']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
