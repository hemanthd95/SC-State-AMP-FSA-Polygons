SCSU AMP: Joseph Wright, Barnwell County
Shapefile: JosephWright.shp/ (EPSG:4326, one feature per previously accepted field)
County map: JosephWright-CountyMap.pdf (topographic)
Field map: JosephWright-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 3 -> ['Phyllis St', 'Dicks St', 'E Charleston St']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
