SCSU AMP: Shannon Lowe, Aiken County
Shapefile: ShannonLowe.shp/ (EPSG:4326; one record per accepted field)
County context map: ShannonLowe-CountyMap.pdf (topographic)
Farmer field map: ShannonLowe-FieldMap.pdf (1 separate satellite field-close-up sheet(s))
Source features: 1. Distinct farm/tract close-up sheets: 1
Road labels visible on each sheet: [5]
Road-label compliance: PASS
Roads: ['Storm Branch Leg', 'State Hwy 145', 'Secretariat Ln', 'Maxwell Rd', 'Riva Ridge Ln']
Physical county need not be the same as workbook/registration county.
These are NOT surveyed, legal, cadastral, CLU, or ownership polygons.
