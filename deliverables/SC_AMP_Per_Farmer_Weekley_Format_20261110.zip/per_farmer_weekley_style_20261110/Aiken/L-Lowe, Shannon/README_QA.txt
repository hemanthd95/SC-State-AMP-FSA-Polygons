SCSU AMP: Shannon Lowe, Aiken County
Shapefile: ShannonLowe.shp/ (EPSG:4326, one feature per previously accepted field)
County map: ShannonLowe-CountyMap.pdf (topographic)
Field map: ShannonLowe-FieldMap.pdf (satellite + named road labels)
Registered feature count: 1
Independently named roads visible: 5 -> ['Storm Branch Leg', 'State Hwy 145', 'Secretariat Ln', 'Maxwell Rd', 'Riva Ridge Ln']
Road-label compliance: PASS
NOTE: original producer workbook county and FSA county may differ from actual physical county.
NOTE: These are not legal, cadastral, CLU, or ownership boundaries.
